
var x = [1, 2, 10]
for (number in x) {
    print(number)
}


var x = [1, 2, 10]
for (var i = 0; i < x.length; i++) {
    const number = x[i];
    console.log(number)
}

x = "10"
